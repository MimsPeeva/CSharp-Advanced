﻿namespace AuthorProblem
{
    [Author("Victor")]
    public class AuthorProblem
    {
        [Author("George")]
        static void Main()
        {

        }
    }
}
