﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HighwayToPeak.Models.Contracts;
using HighwayToPeak.Repositories.Contracts;

namespace HighwayToPeak.Repositories
{
    public class PeakRepository:IRepository<IPeak>
    {
        private HashSet<IPeak> allPeaks;

        public PeakRepository()
        {
            allPeaks = allPeaks;
        }

        public IReadOnlyCollection<IPeak> All { get=>allPeaks; }
        public void Add(IPeak model)
        {
            allPeaks.Add(model);
        }

        public IPeak Get(string name)
        {
            return allPeaks.FirstOrDefault(x => x.Name == name);
        }
    }
}
