namespace FightingArena.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class WarriorTests
    {
        private const string name="Gosho";
        private const int damage = 20;
        private const int hp = 200;
        private const int minAttackHP = 30;
        private Warrior warrior;

        [SetUp]
        public void SetUp()
        {
            warrior = new Warrior(name,damage,hp);
        }

        [Test]
        public void Constructor_HappyPath()
        {
            Assert.AreEqual(warrior.Name,name);
            Assert.AreEqual(warrior.Damage,damage); 
            Assert.AreEqual(warrior.HP,hp);
        }

        [TestCase(null)]
        [TestCase(" ")]
        public void IncorrectName_ThrowsEx(string incorrectName)
        {
            ArgumentException ex =
                Assert.Throws<ArgumentException>(() => warrior = new Warrior(incorrectName, 50, 300), "Name should not be empty or whitespace!");
        }
        [TestCase(-140)]
        [TestCase(0)]
        public void IncorrectDamage_ThrowsEx(int incorrectDamage)
        {
            ArgumentException ex =
                Assert.Throws<ArgumentException>(() => warrior = new Warrior("Gosho", incorrectDamage, 300), "Damage value should be positive!");
        }
        [TestCase(-14)]
        [TestCase(-20)]
        public void IncorrectHP_ThrowsEx(int incorrectHP)
        {
            ArgumentException ex =
                Assert.Throws<ArgumentException>(() => warrior = new Warrior("Gosho", 25, incorrectHP), "HP should not be negative!");
        }
        [Test]
        public void Attack_HappyPath()
        {
            Warrior warrior = new Warrior("Gosho", damage, hp);
            Warrior opponent = new Warrior("Pesho", 10, hp);
            warrior.Attack(opponent);

            Assert.AreEqual(hp-warrior.Damage, opponent.HP);
        }

        [Test]
        public void MinHPWhenAttackOpponent_ThrowsEx()
        {
            warrior = new Warrior("Gosho", 15, 20);
            Warrior opponent = new Warrior("Kiki", 12, 320);
            InvalidOperationException exception = Assert.Throws<InvalidOperationException>(()
                => warrior.Attack(opponent), "Your HP is too low in order to attack other warriors!");
        }

        [Test]
        public void MinOpponentHPWhenAttackWhenTryToAttack_ThrowsEx()
        {
            warrior = new Warrior("Gosho", 15, 200);
            Warrior opponent = new Warrior("Kiki", 12, 10);
            InvalidOperationException exception = Assert.Throws<InvalidOperationException>(()
                => warrior.Attack(opponent), "Enemy HP must be greater than 30 in order to attack him!");
        }
        [Test]
        public void TryToAttackTooStronglyEnemy_ThrowsEx()
        {
            warrior = new Warrior("Gosho", 50, 200);
            Warrior opponent = new Warrior("Kiki", 40, 20);
           InvalidOperationException ex = Assert.Throws<InvalidOperationException>(() => warrior.Attack(opponent), "You are trying to attack too strong enemy");
        }
        [Test]
        public void TryToAttackTooWeakEnemy_ThrowsEx()
        {
            warrior = new Warrior("Gosho", 100, 200);
            Warrior opponent = new Warrior("Kiki", 100, 50);
            warrior.Attack(opponent);
            Assert.AreEqual(0,opponent.HP);
        }
    }
}