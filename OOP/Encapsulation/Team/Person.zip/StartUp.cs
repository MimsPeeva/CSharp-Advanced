﻿namespace PersonsInfo
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //int peopleCount = int.Parse(Console.ReadLine());

            //List<Person> people = new List<Person>();
            //Team team = new Team("Pikachu");

            //for (int i = 0; i < peopleCount; i++)
            //{
            //    string[] commandInfo = Console.ReadLine().Split();
            //    Person person = new Person(commandInfo[0], commandInfo[1], int.Parse(commandInfo[2]), decimal.Parse(commandInfo[3]));

            //    people.Add(person);
            //    team.AddPlayer(person);
            //}

            //Console.WriteLine($"First team has {team.FirstTeam.Count} players.");
            //Console.WriteLine($"Reserve team has {team.ReserveTeam.Count} players.");

        }
    }
}
/*
5
Andrew Williams 20 2200
Newton Holland 57 3333
Rachelle Nelson 27 600
Grigor Dimitrov 25 666.66
Brandi Scott 35 555
*/